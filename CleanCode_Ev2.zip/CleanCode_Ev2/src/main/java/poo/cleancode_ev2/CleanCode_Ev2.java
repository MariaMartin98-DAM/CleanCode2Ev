
package poo.cleancode_ev2;

public class CleanCode_Ev2 {
    public static void main(String[] args) {
        //Creacion del objeto Concesionario
        Concesionario concesionario = new Concesionario(2, 2);
        //Creación de Objetos Coches y Camiones con atributos predeterminados
        Coches coche1 = new Coches(4, "1234ABC", 430.47f, 0.84f, 6.5f, "BMW", "negro"); //Primer Orbjeto Vehiculos -> Coches
        Coches coche2 = new Coches(4, "2589PLK", 150.95f, 1.02f, 7.6f, "Mercedes", "gris"); //Segundo Orbjeto Vehiculos -> Coches
        Camiones camion1 = new Camiones(10,"3690FGR",93.62f, 0.65f, 6.5f, 7500); //Tercer Orbjeto Vehiculos -> Camiones
        Camiones camion2 = new Camiones(18, "1568SDC", 694.22f, 0.58f, 6.5f, 9800); //Cuarto Orbjeto Vehiculos -> Camiones
        
        //Agregar los objetos a los arrays del concesionario
        concesionario.agregarCoche(coche1);
        concesionario.agregarCoche(coche2);
        concesionario.agregarCamion(camion1);
        concesionario.agregarCamion(camion2);
        //Impresion el contenido de los arrays del concesionario
        concesionario.imprimeConcesionario();
        
        //Borrar objeto de los arrays del concesionario
        concesionario.borrarCoche("1234ABC");
        concesionario.borrarCamion("1568SDC");
        
        //Impresion el contenido de los arrays del concesionario
        concesionario.imprimeConcesionario();
        
        //Calculo de los gastos de los viajes
        System.out.printf("Gasto total del viaje: %19.2f \n", coche1.gastosGasolinaViaje());
        System.out.println("-------------------------");
        System.out.printf("Gasto total del viaje: %19.2f \n", coche2.gastosGasolinaViaje());
        System.out.println("-------------------------");
        System.out.printf("Gasto total del viaje: %19.2f \n", camion1.gastosGasolinaViaje());
        System.out.println("-------------------------");
        System.out.printf("Gasto total del viaje: %19.2f \n", camion2.gastosGasolinaViaje());

    }  
}
