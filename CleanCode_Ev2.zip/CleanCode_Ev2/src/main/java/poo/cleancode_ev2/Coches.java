
package poo.cleancode_ev2;

public class Coches extends Vehiculos{
    //Atributos de la clase
    private String modelo;
    private String color;

    //Cosntructor de la clase
    public Coches(int nroRuedas, String matricula,float nroKilometros, float precioGasolina, float consumo, String modelo, String color) {
        super(nroRuedas, matricula, nroKilometros, precioGasolina, consumo);
        this.modelo = modelo;
        this.color = color;
    }
    //Cosntructor vacío de la clase
    public Coches(){
        super();
        modelo = "";
        color = "";
    }
    
    //Getter y Setter de los atributos de la clase
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    
    @Override
    public String toString() {
        return super.toString() + "Coches{" + "modelo=" + this.modelo + ", color=" + this.getColor() + '}';
    }
    
    @Override
    //Método para imprimir los atributos de un Objeto de la clase
    public void imprimirVehiculo(){
        super.imprimirVehiculo();
        System.out.printf("\n\tModelo: %26s \n\tColor: %27s \n"
                , this.modelo, this.color);
    }
}

