
package poo.cleancode_ev2;

public class Vehiculos {
    //Atributos de la clase
    private int nroRuedas;
    private String matricula;
    private float nroKilometros;
    private float precioGasolina;
    private float consumo;
            
    //Constructor
    public Vehiculos(int nroRuedas, String matricula, float nroKilometros, float precioGasolina, float consumo) {
        this.nroRuedas = nroRuedas;
        this.matricula = matricula;
        this.nroKilometros = nroKilometros;
        this.precioGasolina = precioGasolina;
        this.consumo = consumo;
    }
    //Constructor vacio
    public Vehiculos(){
        nroRuedas = 0;
        matricula = "";
        nroKilometros = 0;
        precioGasolina = 0;
        consumo = 0;
    }
    
    public int getNroRuedas() {
        return nroRuedas;
    }
    public void setNroRuedas(int nroRuedas) {
        this.nroRuedas = nroRuedas;
    }

    public String getMatricula() {
        return matricula;
    }
    public void setPeso(String matricula) {
        this.matricula = matricula;
    }
    public float getNroKilometros() {
        return nroKilometros;
    }
    public void setNroKilometros(float nroKilometros) {
        this.nroKilometros = nroKilometros;
    }

    public float getPrecioGasolina() {
        return precioGasolina;
    }
    public void setPrecioGasolina(float precioGasolina) {
        this.precioGasolina = precioGasolina;
    }

    public float getConsumo() {
        return consumo;
    }
    public void setConsumo(float consumo) {
        this.consumo = consumo;
    }

    @Override
    public String toString() {
        return "Vehiculos{" + "nroRuedas=" + this.getNroRuedas() + ", matricula=" + this.getMatricula() + ", nroKilometros=" + this.getNroKilometros() + ", precioGasolina=" + this.getPrecioGasolina() + ", consumo=" + this.getConsumo() + '}';
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.getMatricula() == null) ? 0 : this.getMatricula().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Vehiculos other = (Vehiculos) obj;
        if (this.getMatricula() == null) {
            if (other.getMatricula() != null)
                return false;
        } else if (!this.getMatricula().equals(other.getMatricula()))
            return false;
        return true;
    }  
    
    //Método para calcular el coste total de la gasolina de un coche
    public double gastosGasolinaViaje(){
        double costeTotal= (this.getNroKilometros() * 2 / this.getConsumo()) * this.getPrecioGasolina();
        return costeTotal;
    }
    
    //Método para imprimir los atributos de un Objeto de la clase
    public void imprimirVehiculo(){
        System.out.printf("CARACTERISTICAS: \n\tNumero de ruedas: %16d \n\tMatricula: %23s \n\tNumero de Kilometros ida: %8.3f \n\tPrecio combustible: %14.2f \n\tConsumo: %25.2f"
                , this.getNroRuedas(), this.getMatricula(), this.getNroKilometros(), this.getPrecioGasolina(), this.getConsumo());
    }
    
    //Método para comprobar que la matricula es correcta
    public boolean comprobarMatricula(){
        return this.getMatricula().toUpperCase().matches("^[0-9]{4}[A-Z]{3}$"); //Uso de expresiones regulares: máximo 4 dígitos del 0 al 9 y maximo 3 letras de la A a la Z
    }
}
