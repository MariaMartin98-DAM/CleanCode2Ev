
package poo.cleancode_ev2;

public class Camiones extends Vehiculos {
    //Atributos de la clase
    private int masaMaxAutorizada;

    public Camiones(int nroRuedas, String matricula, float nroKilometros, float precioGasolina, float consumo, int masaMaxAutorizada) {
        super(nroRuedas, matricula, nroKilometros, precioGasolina, consumo);
        this.masaMaxAutorizada = masaMaxAutorizada;
    }

    public Camiones(float masaMaxAutorizada) {
        super();
        masaMaxAutorizada = 0;
    }

    public int getMasaMaxAutorizada() {
        return masaMaxAutorizada;
    }
    public void setMasaMaxAutorizada(int masaMaxAutorizada) {
        this.masaMaxAutorizada = masaMaxAutorizada;
    }

    @Override
    public String toString() {
        return super.toString() + "Camiones{" + "masaMaxAutorizada=" + this.getMasaMaxAutorizada() + '}';
    }
    
    @Override
    //Método para imprimir los atributos de un Objeto de la clase
    public void imprimirVehiculo(){
        super.imprimirVehiculo();
        System.out.printf("\n\tMasa Maxima Autorizada: %10d\n"
                , this.masaMaxAutorizada);
    }
    
}
