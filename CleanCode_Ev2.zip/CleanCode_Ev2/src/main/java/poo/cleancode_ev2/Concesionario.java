package poo.cleancode_ev2;

import java.util.Arrays;

public class Concesionario {

    //Atributos de la clase
    private Coches[] coches;
    private int cantidadCoches;
    private Camiones[] camiones;
    private int cantidadCamiones;

    //Constructor
    public Concesionario(int nroCoches, int norCamiones) {
        this.coches = new Coches[nroCoches];
        this.camiones = new Camiones[norCamiones];
        this.cantidadCoches = 0;
        this.cantidadCamiones = 0;
    }

    //Constructor vacio
    public Concesionario() {
        coches = new Coches[0];
        camiones = new Camiones[0];
        cantidadCoches = 0;
        cantidadCamiones = 0;
    }

    public Coches[] getCoches() {
        return coches;
    }

    public void setCoches(Coches[] coches) {
        this.coches = coches;
    }

    public int getCantidadCoches() {
        return cantidadCoches;
    }

    public void setCantidadCoches(int cantidadCoches) {
        this.cantidadCoches = cantidadCoches;
    }

    public Camiones[] getCamiones() {
        return camiones;
    }

    public void setCamiones(Camiones[] camiones) {
        this.camiones = camiones;
    }

    public int getCantidadCamiones() {
        return cantidadCamiones;
    }

    public void setCantidadCamiones(int cantidadCamiones) {
        this.cantidadCamiones = cantidadCamiones;
    }

    @Override
    public String toString() {
        return "Concesionario{" + "coches=" + this.getCoches() + ", cantidadCoches=" + this.getCantidadCoches() + ", camiones="
                + this.getCamiones() + ", cantidadCamiones=" + this.getCantidadCamiones() + '}';
    }

    // Método que imprime los objetos de los array de Concesionario
    public void imprimeConcesionario() {
        System.out.println("VEHICULOS:");
        // Imprimir los coches
        for (Coches car : coches) {
            if (car != null) {
                car.imprimirVehiculo();
            }
        }
        // Imprimir los camiones
        for (Camiones truck : camiones) {
            if (truck != null) {
                truck.imprimirVehiculo();
            }
        }
    }

    /**
     * Método que añade un objeto Coche en el array
     *
     * @param car a añadir
     */
    public void agregarCoche(Coches car) {
        try {
            if (cantidadCoches < coches.length && car.comprobarMatricula()) {
                coches[cantidadCoches] = car;
                cantidadCoches++;
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    }

    /**
     * Método que añade un objeto Coche en el array
     *
     * @param truck a añadir
     */
    public void agregarCamion(Camiones truck) {
        try {
            if (cantidadCamiones < camiones.length && truck.comprobarMatricula() == true) {
                camiones[cantidadCamiones] = truck;
                cantidadCamiones++;
            } else {
                System.out.println("Matrícula no válida");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    }

    /**
     * Método que borrar un objeto coche del array. Objeto identificado por la
     * matricula
     *
     * @param matricula del estudiante
     */
    public void borrarCoche(String matricula) {
        try {
            for (int i = 0; i < cantidadCoches; i++) {
                if (coches[i].getMatricula().equals(matricula)) {
                    // Mover los elementos siguientes hacia atrás
                    System.arraycopy(coches, i + 1, coches, i, cantidadCoches - i - 1);
                    coches[cantidadCoches - 1] = null; // Limpiar el último elemento
                    cantidadCoches--;
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    }

    /**
     * Método que borrar un objeto camion del array. Objeto identificado por la
     * matricula
     *
     * @param matricula del camion
     */
    public void borrarCamion(String matricula) {
        try {
            for (int i = 0; i < cantidadCamiones; i++) {
                if (camiones[i].getMatricula().equals(matricula)) {
                    // Mover los elementos siguientes hacia atrás
                    System.arraycopy(camiones, i + 1, camiones, i, cantidadCamiones - i - 1);
                    camiones[cantidadCamiones - 1] = null; // Limpiar el último elemento
                    cantidadCamiones--;
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    }

    /**
     * Método que devuelve el array de objetos coches
     *
     * @return array de coches
     */
    public Coches[] obtenerCoches() {
        return Arrays.copyOf(coches, cantidadCoches);
    }

    /**
     * Método que devuelve el array de objetos camiones
     *
     * @return array de camiones
     */
    public Camiones[] obtenerCamiones() {
        return Arrays.copyOf(camiones, cantidadCamiones);
    }

}
