import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
//import java.util.Arrays;
import poo.cleancode_ev2.Camiones;
import poo.cleancode_ev2.Coches;
import poo.cleancode_ev2.Concesionario;
//import poo.cleancode_ev2.Vehiculos;

public class testConcesionario {
    //creación del objeto concesionario, el array resCoches,resCamiones y los objetos coches y camiones
    private static Concesionario concesionario;
    private static Coches[] coches;
    private static Camiones[] camiones;
    private static Coches[] resCoches;
    private static Camiones[] resCamiones;
    
    @BeforeAll
    //Inicialización de los objetos de la clase Concesionario
    public static void setUpAll() {
        coches = new Coches[]{
            new Coches(4, "1234ABC", 430.47f, 0.84f, 6.5f, "BMW", "negro"),
            new Coches(4, "2589PLK", 150.95f, 1.02f, 7.6f, "Mercedes", "gris")
        };
        camiones = new Camiones[]{
            new Camiones(10,"3690FGR",93.62f, 0.65f, 6.5f, 7500),
            new Camiones(18, "1568SDC", 694.22f, 0.58f, 6.5f, 9800)
        };
        concesionario = new Concesionario(5,5);
        resCoches = concesionario.obtenerCoches();
        resCamiones = concesionario.obtenerCamiones();
        
        System.out.println("Inicialización de los objetos de la clase Concesionario");
    }
    
    @BeforeEach
    public void setUp() {
        concesionario = new Concesionario(5,5);
        //agregar al concesionario todos los Coches
        for (Coches car : coches) {
            concesionario.agregarCoche(car);
        }
        //agregar al Concesionario todos los Camiones
        for (Camiones truck : camiones) {
            concesionario.agregarCamion(truck);
        }
        
        System.out.println("Inicialización antes de cada prueba del objeto Concesionario"); 
    }
    
//    @Test
//    @DisplayName ("Test de verificar que se agrega un objeto coche al array del concerionario coches")
//    public void testAgregarCoche(){
//        System.out.println("TEST AGREGAR COCHES");
//        //crear un estudiante nuevo
//        Coches cocheNuevo = new Coches(4, "4669CED", 723.9f, 0.94f, 6.8f, "VW", "blanco");
//        //agregar al gestor el estudiante nuevo
//        concesionario.agregarCoche(cocheNuevo);
//        //Obtener el array resultado tras agregar un Estudiante
//        resCoches = concesionario.obtenerCoches();
//        //crear el array esperado
//        Coches[] arrayEsperado = new Coches[]{
//            new Coches(4, "1234ABC", 430.47f, 0.84f, 6.5f, "BMW", "negro"),
//            new Coches(4, "2589PLK", 150.95f, 1.02f, 7.6f, "Mercedes", "gris"),
//            cocheNuevo
//        };
//        //comparar arrays (assertArrayEquals)
//        assertArrayEquals(arrayEsperado,resCoches);
//        System.out.println(resCoches.length);
//    }
//    @Test
//    @DisplayName ("Test de verificar que se agrega un objeto camion al array del concerionario camiones")
//    public void testAgregarCamion(){
//        System.out.println("TEST AGREGAR CAMIONES");
////        //crear un estudiante nuevo
////        Camiones camionNuevo = new Camiones(18, "1568SDC", 694.22f, 0.58f, 6.5f, 9800);
////        //agregar al gestor el estudiante nuevo
////        concesionario.agregarCamion(camionNuevo);
////        //Obtener el array resultado tras agregar un Estudiante
////        resCamiones = concesionario.obtenerCamiones();
////        //crear el array esperado
////        Camiones[] arrayEsperado = new Camiones[]{
////            new Camiones(10,"3690FGR",93.62f, 0.65f, 6.5f, 7500),
////            new Camiones(18, "1568SDC", 694.22f, 0.58f, 6.5f, 9800),
////            camionNuevo
////        };
////        //comparar arrays (assertArrayEquals)
////        assertArrayEquals(arrayEsperado, resCamiones);
////        System.out.println(resCamiones.length);
////    }
////
////    @Test
////    @DisplayName ("Test de verificar que se borra un objeto coche del array del concerionario coches")
////    public void testBorrarCoche(){
////        System.out.println("TEST BORRAR COCHES");
////        //borrar estudiante
////        concesionario.borrarCoche("1234ABC");
////        //obtener el array resultado tras borrar el estudiante
////        resCoches = concesionario.obtenerCoches();
////        //crear el array esperado
////        Coches[] arrayEsperado = new Coches[]{
////            new Coches(4, "2589PLK", 150.95f, 1.02f, 7.6f, "Mercedes", "gris"),
////        };
////        //comparar arrays (assertArrayEquals)
////        assertArrayEquals(arrayEsperado, resCoches);
////        System.out.println(resCoches.length); 
////    }
////    
//    @Test
//    @DisplayName ("Test de verificar que se borra un objeto camion del array del concerionario camiones")
//    public void testBorrarCamion(){
//        System.out.println("TEST BORRAR CAMIONES");
//        //borrar estudiante
//        concesionario.borrarCamion("1568SDC");
//        //obtener el array resultado tras borrar el estudiante
//        resCamiones = concesionario.obtenerCamiones();
//        //crear el array esperado
//        Camiones[] arrayEsperado = new Camiones[]{
//            new Camiones(10,"3690FGR",93.62f, 0.65f, 6.5f, 7500)
//        };
//        //comparar arrays (assertArrayEquals)
//        assertArrayEquals(arrayEsperado, resCamiones);
//        System.out.println(resCamiones.length);
//    }
    @Test
    @DisplayName ("Test de verificar que se obtiene el array con los objetos coches del concesionario")
    public void testObtenerCoche(){
        System.out.println("TEST OBTENER COCHES");
        resCoches = concesionario.obtenerCoches();
        Coches[] arrayEsperado = new Coches[]{
            new Coches(4, "1234ABC", 430.47f, 0.84f, 6.5f, "BMW", "negro"),
            new Coches(4, "2589PLK", 150.95f, 1.02f, 7.6f, "Mercedes", "gris")
        };
        assertArrayEquals(arrayEsperado, resCoches); 
    }
//    @Test
//    @DisplayName ("Test de verificar que se obtiene el array con los objetos camiones del concesionario")
//    public void testObtenerCamion(){
//        System.out.println("TEST OBTENER CAMIONES");
//        resCamiones = concesionario.obtenerCamiones();
//        Camiones[] arrayEsperado = new Camiones[]{
//            new Camiones(10,"3690FGR",93.62f, 0.65f, 6.5f, 7500),
//            new Camiones(18, "1568SDC", 694.22f, 0.58f, 6.5f, 9800)
//        };
//        assertArrayEquals(arrayEsperado, resCamiones);  
//    }
  
    @AfterEach
    public void tearDown() {
        System.out.println("Tareas de limpieza después de cada prueba");
    }
    
    @AfterAll
    //todos los valores a null
    public static void tearDownAll() {
        concesionario = null;
        coches = null;
        camiones = null;
        resCoches = null;
        resCamiones = null;
        System.out.println("Final de las pruebas JUnit");
    }
}
