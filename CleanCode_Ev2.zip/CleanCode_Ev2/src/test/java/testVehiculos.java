
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import poo.cleancode_ev2.Vehiculos;


public class testVehiculos {
    private static Vehiculos nuevo0;
    private static Vehiculos nuevo1;
    private static Vehiculos nuevo2;
    
    @BeforeAll
    //inicialización de los objetos de la clase Vehiculo
    public static void setUpAll() {
        nuevo0 = new Vehiculos(4, "1234ABC", 430.47f, 0.84f, 6.5f);
        nuevo1 = new Vehiculos(4, "2589PLK", 150.95f, 1.02f, 7.6f);
        nuevo2 = new Vehiculos(10,"3690FGR",93.62f, 0.65f, 6.5f);
        System.out.println("Inicialización de los objetos de la clase Estudiante");
    }
    
    @BeforeEach
    public void setUp() {
        System.out.println("Inicialización antes de cada prueba");
    }
    
    @Test
    @DisplayName ("Test de verificar que se calcula correctamente el gasto de la gasolina del viaje")
    public void testCalculoGasolinaViaje() {
        System.out.println("TEST CALCULO DE LA GASOLINA DEL VIAJE");
        assertAll(
            () -> assertEquals(111.26 , nuevo0.gastosGasolinaViaje(), 0.1),
            () -> assertEquals(40.52 , nuevo1.gastosGasolinaViaje(), 0.1),
            () -> assertEquals(18.72 , nuevo2.gastosGasolinaViaje(), 0.1)
        );
    }
    
    @Test
    @DisplayName ("Test de verificar que se introducen bien las matriculas de los vehículos")
    public void testComprobarMatricula() {
        System.out.println("TEST COMPROBAR MARTICULA");
        Vehiculos nuevo3 = new Vehiculos(18, "D1111CV", 694.22f, 0.58f, 6.5f);
        assertAll(
                () -> assertTrue(nuevo0.comprobarMatricula()),
                () -> assertTrue(nuevo1.comprobarMatricula()),
                () -> assertTrue(nuevo2.comprobarMatricula()),
                () -> assertFalse(nuevo3.comprobarMatricula())
        );
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Tareas de limpieza después de cada prueba");
    }
    
    @AfterAll
    public static void tearDownAll() {
        nuevo0 = null;
        nuevo1 = null;
        nuevo2 = null;
        System.out.println("Final de las pruebas JUnit");
    }

}
